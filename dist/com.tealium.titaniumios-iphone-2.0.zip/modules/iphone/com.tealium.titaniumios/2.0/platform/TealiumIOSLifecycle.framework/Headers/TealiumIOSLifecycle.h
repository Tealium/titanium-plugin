//
//  TealiumIOS_Lifecycle.h
//  TealiumIOS_Lifecycle
//
//  Created by Jason Koo on 7/18/16.
//  Copyright © 2016 Tealium. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TealiumIOS_Lifecycle.
FOUNDATION_EXPORT double TealiumIOS_LifecycleVersionNumber;

//! Project version string for TealiumIOS_Lifecycle.
FOUNDATION_EXPORT const unsigned char TealiumIOS_LifecycleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TealiumIOS_Lifecycle/PublicHeader.h>

@import TealiumIOS;

#import <TealiumIOSLifecycle/Tealium+Lifecycle.h>
#import <TealiumIOSLifecycle/TEALConfiguration+Lifecycle.h>
