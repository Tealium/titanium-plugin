//
//  TEALWebView.h
//  TealiumIOS
//
//  Created by Jonathan Wong on 2/12/19.
//  Copyright © 2019 Tealium. All rights reserved.
//

typedef NS_ENUM(NSInteger, TEALWebViewType) {
    TEALDefaultWebView,
    TEALWKWebView
};

